export default function Finance() {
    return (
        <div>
            <h1>Finance</h1>
            <h2>TBD in phase2</h2>

        </div>
    );
}