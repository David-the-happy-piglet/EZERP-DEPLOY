// API configuration
export const API_URL = 'https://ez-erp-backend.onrender.com/api';
//export const API_URL = 'http://localhost:3000/api';